import sqlite3

sql='''
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    doctor_id INTEGER NOT NULL,
    sender_type TEXT NOT NULL,
    message TEXT NOT NULL,
    is_read INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id),
    FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);
'''

conn=sqlite3.connect('hospital_system.db')
cur=conn.cursor()
cur.executescript(sql)
conn.commit()
cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messages'")
print('messages table exists:', cur.fetchone() is not None)
conn.close()

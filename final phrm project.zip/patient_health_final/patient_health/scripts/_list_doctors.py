import sqlite3
conn = sqlite3.connect('../hospital_system.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()
rows = c.execute('SELECT id,name,email,gender,profile_pic FROM doctors LIMIT 5').fetchall()
print([dict(r) for r in rows])
conn.close()

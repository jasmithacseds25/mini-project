"""
Generate PNG exports for SVG-style avatars using Pillow (approximate shapes).
Run: python scripts/generate_avatar_pngs.py
This will create 128x128 and 64x64 PNGs in static/icons/png/
"""
from PIL import Image, ImageDraw
import os

SRC_DIR = os.path.join(os.path.dirname(__file__), '..', 'static', 'icons')
OUT_DIR = os.path.join(os.path.dirname(__file__), '..', 'static', 'icons', 'png')
os.makedirs(OUT_DIR, exist_ok=True)

AVATARS = [
    ('avatar_male_blue', 'male'),
    ('avatar_female_blue', 'female'),
]

PRIMARY = (37, 99, 235)  # #2563eb RGB
BG = (247, 251, 255)
WHITE = (255,255,255)
DARK = (15,23,36)

SIZES = [128, 64]

for name, label in AVATARS:
    for size in SIZES:
        img = Image.new('RGBA', (size, size), BG)
        draw = ImageDraw.Draw(img)
        # shoulders
        draw.rounded_rectangle([size*0.14, size*0.6, size*0.86, size*0.88], radius=size*0.08, fill=WHITE)
        # face
        cx, cy = size//2, int(size*0.32)
        r = int(size*0.17)
        draw.ellipse([cx-r, cy-r, cx+r, cy+r], fill=WHITE)
        # hair / style for the two avatars
        if label == 'male':
            draw.pieslice([cx-r*1.6, cy-r*1.1, cx+r*1.6, cy+r*0.6], start=180, end=360, fill=PRIMARY)
            # subtle neck shade
            draw.arc([cx-r*0.7, cy+r*0.4, cx+r*0.7, cy+r*1.6], start=180, end=360, fill=(30,64,175), width=max(1,int(size*0.03)))
        elif label == 'female':
            draw.rectangle([cx-r*1.2, cy-r*0.6, cx+r*1.2, cy+r*1.5], fill=PRIMARY)
            draw.ellipse([cx-r, cy-r, cx+r, cy+r], fill=WHITE)

        out_path = os.path.join(OUT_DIR, f"{name}_{size}px.png")
        img.save(out_path)
        print('Saved', out_path)

print('PNG generation completed.')

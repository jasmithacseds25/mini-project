import urllib.request, urllib.parse
url='http://127.0.0.1:5000/doctor/login'
data=urllib.parse.urlencode({'email':'avanialladi@gmail.com','password':'wrongpass'}).encode()
req=urllib.request.Request(url, data=data)
resp=urllib.request.urlopen(req)
print('Status', resp.status)
print(resp.read(500).decode('utf-8'))

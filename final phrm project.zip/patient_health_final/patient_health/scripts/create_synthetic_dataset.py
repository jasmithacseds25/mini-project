"""
Create a small synthetic dataset from SVG/PNG avatars and write them into data/synthetic_avatars/<label>/
Label mapping: short, shaved, parted -> 'male'; long, bun, ponytail, bob, layered -> 'female'
Run: python scripts/create_synthetic_dataset.py
"""
import os
import shutil

SRC_DIR = os.path.join(os.path.dirname(__file__), '..', 'static', 'icons', 'png')
DST_DIR = os.path.join(os.path.dirname(__file__), '..', 'data', 'synthetic_avatars')

LABEL_MAP = {
    'avatar_male_blue': 'male',
    'avatar_female_blue': 'female'
}

os.makedirs(DST_DIR, exist_ok=True)
for fname in os.listdir(SRC_DIR):
    if not fname.endswith('.png'):
        continue
    base = fname.split('_')[0]
    label = LABEL_MAP.get(base, 'unknown')
    if label == 'unknown':
        continue
    out_dir = os.path.join(DST_DIR, label)
    os.makedirs(out_dir, exist_ok=True)
    # copy and rename for uniqueness
    dst = os.path.join(out_dir, fname)
    shutil.copy(os.path.join(SRC_DIR, fname), dst)
    print('Copied', fname, '->', label)

print('Synthetic dataset creation complete. Samples in', DST_DIR)

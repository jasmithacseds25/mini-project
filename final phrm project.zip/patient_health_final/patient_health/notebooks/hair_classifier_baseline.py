"""
Baseline hair-shape gender classifier using synthetic silhouette dataset.
- Loads images from data/synthetic_avatars/{male,female}
- Converts to grayscale 32x32 and flattens
- Trains an SVM and prints classification report
"""
import os
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import StandardScaler
import numpy as np
from PIL import Image
import joblib

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data', 'synthetic_avatars')

def load_dataset(img_size=(32,32)):
    X = []
    y = []
    label_map = {}
    idx = 0
    for label in sorted(os.listdir(DATA_DIR)):
        label_dir = os.path.join(DATA_DIR, label)
        if not os.path.isdir(label_dir):
            continue
        label_map[idx] = label
        for fname in os.listdir(label_dir):
            path = os.path.join(label_dir, fname)
            try:
                im = Image.open(path).convert('L').resize(img_size)
                arr = np.asarray(im, dtype=np.float32)/255.0
                X.append(arr.flatten())
                y.append(idx)
            except Exception as e:
                print('Failed to load', path, e)
        idx += 1
    return np.array(X), np.array(y), label_map

if __name__ == '__main__':
    X, y, label_map = load_dataset()
    if len(X) == 0:
        print('No data found. Run scripts/generate_avatar_pngs.py and scripts/create_synthetic_dataset.py first.')
        exit(1)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    clf = SVC(kernel='linear', probability=True)
    clf.fit(X_train_s, y_train)
    preds = clf.predict(X_test_s)
    print('Label map:', label_map)
    print(classification_report(y_test, preds))
    print('Confusion matrix:\n', confusion_matrix(y_test, preds))

    os.makedirs(os.path.join(os.path.dirname(__file__), '..', 'models'), exist_ok=True)
    joblib.dump({'model': clf, 'scaler': scaler, 'label_map': label_map}, os.path.join(os.path.dirname(__file__), '..', 'models', 'svm_hair_baseline.pkl'))
    print('Model saved to models/svm_hair_baseline.pkl')

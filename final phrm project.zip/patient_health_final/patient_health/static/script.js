// Form validation
document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.display = 'none';
        }, 5000);
    });

    // Form validation
    const forms = document.querySelectorAll('.form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const inputs = this.querySelectorAll('input[required], textarea[required], select[required]');
            let isValid = true;

            inputs.forEach(input => {
                if (!input.value.trim()) {
                    input.style.borderColor = 'var(--danger)';
                    isValid = false;
                } else {
                    input.style.borderColor = 'rgba(0,0,0,0.06)';
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
    });

    // Clear input border on focus
    const inputs = document.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.style.borderColor = 'rgba(0,0,0,0.06)';
        });
    });

    // Theme toggle (light / dark) — uses localStorage and prefers-color-scheme as default
    const themeToggleBtn = document.getElementById('themeToggle');
    const root = document.documentElement;

    function applyTheme(theme) {
        if (theme === 'dark') {
            root.setAttribute('data-theme', 'dark');
            if (themeToggleBtn) { themeToggleBtn.textContent = '☀️'; themeToggleBtn.setAttribute('aria-pressed', 'true'); }
        } else {
            root.removeAttribute('data-theme');
            if (themeToggleBtn) { themeToggleBtn.textContent = '🌙'; themeToggleBtn.setAttribute('aria-pressed', 'false'); }
        }
    }

    let savedTheme = localStorage.getItem('theme');
    if (!savedTheme) {
        savedTheme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
    }
    applyTheme(savedTheme);

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', function() {
            const isDark = root.getAttribute('data-theme') === 'dark';
            const next = isDark ? 'light' : 'dark';
            applyTheme(next);
            localStorage.setItem('theme', next);
        });
    }
});

// Search functionality
function searchPatients(query) {
    if (query.length < 2) {
        document.getElementById('searchResults').innerHTML = '';
        return;
    }

    fetch('/api/search-patients?q=' + encodeURIComponent(query))
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length > 0) {
                html = '<div class="dropdown">';
                data.forEach(patient => {
                    html += `<a href="/doctor/patient/${patient.id}" class="dropdown-item">${patient.name} (${patient.email})</a>`;
                });
                html += '</div>';
            }
            document.getElementById('searchResults').innerHTML = html;
        })
        .catch(error => console.error('Error:', error));
}

// Print functionality for reports
function printReport() {
    window.print();
}

// Export to CSV
function exportToCSV(filename) {
    const table = document.querySelector('.data-table');
    if (!table) {
        alert('No table found to export');
        return;
    }

    let csv = [];
    const rows = table.querySelectorAll('tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('th, td');
        const rowData = [];
        cells.forEach(cell => {
            rowData.push('"' + cell.textContent.replace(/"/g, '""') + '"');
        });
        csv.push(rowData.join(','));
    });

    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || 'export.csv';
    a.click();
    window.URL.revokeObjectURL(url);
}

// Medication tick handling: mark medication timeslot as taken/un-taken
document.addEventListener('change', function(e) {
    if (!e.target || !e.target.classList) return;
    if (e.target.classList.contains('med-tick')) {
        if (e.target.disabled) {
            // already submitted
            alert('This entry has been submitted and cannot be changed.');
            e.target.checked = !e.target.checked;
            return;
        }

        const prescriptionId = e.target.dataset.prescriptionId;
        const timeslot = e.target.dataset.timeslot;
        const taken = e.target.checked ? 1 : 0;

        fetch('/patient/mark-medication', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prescription_id: prescriptionId, timeslot: timeslot, taken: taken })
        })
        .then(res => res.json())
        .then(data => {
            if (!data || !data.success) {
                console.error('Error marking medication:', data && data.error);
                alert(data && data.error ? data.error : 'Could not update medication status.');
                // revert checkbox state
                e.target.checked = !taken;
            } else {
                // Update the UI so the per-timeslot Submit button appears/disappears immediately
                try {
                    const label = e.target.closest('label');
                    if (!label) return;
                    const existingBtn = label.querySelector('.med-submit');
                    const timeslot = e.target.dataset.timeslot;
                    if (e.target.checked) {
                        // add per-timeslot submit button if not submitted already
                        if (!label.querySelector('.badge-submitted') && !existingBtn) {
                            const btn = document.createElement('button');
                            btn.className = 'btn btn-success btn-sm med-submit';
                            btn.dataset.prescriptionId = prescriptionId;
                            btn.dataset.timeslot = timeslot;
                            btn.textContent = 'Submit';
                            label.appendChild(btn);
                        }
                    } else {
                        // remove per-timeslot submit button if present
                        if (existingBtn) existingBtn.remove();
                    }
                } catch (err) {
                    console.error('Error updating submit UI', err);
                }
            }
        })
        .catch(err => {
            console.error('Network error marking medication', err);
            alert('Network error. Please try again.');
            e.target.checked = !taken;
        });
    }
});

// Handle Submit button click for prescriptions
document.addEventListener('click', function(e) {
    if (!e.target || !e.target.classList) return;
    if (e.target.classList.contains('med-submit')) {
        const btn = e.target;
        const prescriptionId = btn.dataset.prescriptionId;
        const timeslot = btn.dataset.timeslot;
        const confirmMsg = timeslot ? 'Submit today\'s taken medicine for this timeslot? This cannot be changed.' : 'Submit today\'s taken medicines for this prescription? This cannot be changed.';
        if (!confirm(confirmMsg)) return;

        const payload = { prescription_id: prescriptionId };
        if (timeslot) payload.timeslot = timeslot;

        fetch('/patient/submit-medication', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(data => {
            if (data && data.success) {
                if (timeslot) {
                    // disable only the related checkbox for this timeslot and replace the button with a badge
                    const checkbox = document.querySelector('.med-tick[data-prescription-id="' + prescriptionId + '"][data-timeslot="' + timeslot + '"]');
                    if (checkbox) { checkbox.disabled = true; checkbox.dataset.submitted = '1'; }

                    const label = document.createElement('span');
                    label.className = 'badge-submitted';
                    label.textContent = 'Submitted';
                    btn.replaceWith(label);
                } else {
                    // fallback: disable all related checkboxes and replace button
                    const checkboxes = document.querySelectorAll('.med-tick[data-prescription-id="' + prescriptionId + '"]');
                    checkboxes.forEach(cb => { cb.disabled = true; cb.dataset.submitted = '1'; });

                    const label = document.createElement('span');
                    label.className = 'badge-submitted';
                    label.textContent = 'Submitted';
                    btn.replaceWith(label);
                }
            } else {
                alert(data && data.error ? data.error : 'Could not submit.');
            }
        })
        .catch(err => {
            console.error('Error submitting medication', err);
            alert('Network error. Please try again.');
        });
    }
});
